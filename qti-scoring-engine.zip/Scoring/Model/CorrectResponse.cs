﻿namespace Citolab.QTI.ScoringEngine.Model
{
    internal class CorrectResponse
    {
        public float Score { get; set; }
        public string Response { get; set; }
    }
}