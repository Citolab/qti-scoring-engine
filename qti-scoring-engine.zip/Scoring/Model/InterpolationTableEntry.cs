﻿namespace Citolab.QTI.ScoringEngine.Model
{
    internal class InterpolationTableEntry
    {
        public float SourceValue { get; set; }
        public float TargetValue { get; set; }
    }
}
