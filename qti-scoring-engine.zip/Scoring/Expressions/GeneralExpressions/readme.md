﻿# 15.1. Builtin General Expressions

- qti-base-value
- qti-variable (different implementations for outcome and response processing)
- qti-null
- qti-default*
- qti-math-constant*
- qti-random-integer*
- qti-random-float*
### outcomeProcessing only
- qti-test-variable
- qti-item-subset*
- qti-outcomeMaximum*
- qti-outcomeMinimum*
- qti-numberCorrect*
- qti-numberIncorrect*
- qti-numberResponded*
- qti-numberPresented*
- qti-numberSelected* 
### responseProcessing only
- qti-correct
- qti-map-response
- qti-map-response-point

* = not supported

