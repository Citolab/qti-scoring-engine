﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Citolab.QTI.ScoringEngine.Expressions.GeneralExpressions
{
    internal interface IResponseProcessingExpression : IGeneralExpression
    {
    }
}
