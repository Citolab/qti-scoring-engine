# Todo's

## unittest for
* customOperators added from outside
* multiple assessmentResults
* throwing errors

## performance
* optimize for batch processing:
    * setup all expressions before processing, now the responseProcessing is processed line by line for each item this can be done at forehand. This might be a bit slower for processing single results.
    * Process in parallell
* Unittest performance 

## v3 Result Reporting
QTI v3 Results Reporting Specification

## full-support

Support all expressions.
