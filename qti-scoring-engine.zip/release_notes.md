## 1.0.0-beta.2

* refactored way of getting values
* 3.0 packages
* lt, lte, gt, substring, ordered in match, equalRounded, roud
* orderInteraction; implemented match for all cardinalities
* selectPoint, positionObjectInteraction; implemented scoring with baseType point

## 1.0.0-beta.1

Initial release