﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Console.Scoring
{
    public class ResourceRef
    {
        public string Identifier { get; set; }
        public string Href { get; set; }
    }
}
