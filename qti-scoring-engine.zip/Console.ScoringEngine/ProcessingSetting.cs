﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console.Scoring
{
    public class ProcessingSetting
    {
        public string PackageFileLocation { get; set; }
        public string AssessmentResultFolderLocation { get; set; }
    }
}
